#!/usr/bin/env bash
#
# Copyright (c) 2019-present The Bitcoin Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

export LC_ALL=C.UTF-8

export SDK_URL=${SDK_URL:-https://bitcoincore.org/depends-sources/sdks}

export CI_IMAGE_NAME_TAG="mirror.gcr.io/debian:trixie" # Check that https://packages.debian.org/trixie/clang (version 19, similar to guix) can cross-compile
export HOST=arm64-apple-darwin
export PACKAGES="clang lld llvm zip"
export XCODE_VERSION=26.1.1
export XCODE_BUILD_ID=17B100
export OSX_SDK_SHA256=9600fa93644df674ee916b5e2c8a6ba8dacf631996a65dc922d003b98b5ea3b1
export RUN_UNIT_TESTS=false
export RUN_FUNCTIONAL_TESTS=false
export BUILD_TARGETS="all deploy"
printf -v BITCOIN_CONFIG "%q " \
 --preset=dev-mode \
 -DWITH_USDT=OFF \
 -DREDUCE_EXPORTS=ON
export BITCOIN_CONFIG
