#!/usr/bin/env bash
#
# Copyright (c) 2020-present The Bitcoin Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

export LC_ALL=C.UTF-8

export CI_IMAGE_NAME_TAG="mirror.gcr.io/alpine:3.24"
export CI_BASE_PACKAGES="build-base musl-dev pkgconf curl ccache make ninja git python3-dev py3-pip which patch xz procps rsync util-linux bison e2fsprogs cmake dash linux-headers"
export PIP_PACKAGES="--break-system-packages pyzmq pycapnp"
export DEP_OPTS="DEBUG=1"
printf -v BITCOIN_CONFIG "%q " \
 --preset=dev-mode \
 -DREDUCE_EXPORTS=ON \
 -DCMAKE_BUILD_TYPE=Debug
export BITCOIN_CONFIG
export TEST_RUNNER_EXTRA="--v2transport --usecli --extended --exclude feature_dbcrash"  # Run extended tests under --usecli and --v2transport, but exclude the very slow dbcrash
export BITCOIN_CMD="bitcoin -m" # Used in functional tests
